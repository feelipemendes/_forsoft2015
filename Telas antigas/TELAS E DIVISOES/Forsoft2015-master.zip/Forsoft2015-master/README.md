# Forsoft2015
Repositório da turma de 2015 do projeto Forsoft

[LEIAM ATÉ O FINAL – Perguntas cujas respostas estejam explicitamente contidas aqui serão ignoradas!] Divisão dos Trabalhos.
Primeiro desculpa o atraso pessoal, mas aqui vai.

Falarei primeiro sobre as regras para a construção das telas HTML e CSS:

1.	Só editar o HTML, pois o CSS está padronizado. Portanto NÃO editem o CSS. Qualquer Dúvida ou problema procurem a mim ou ao Guilherme Favoreto. 
2.	Respeitar os limites de edições indicados, por comentários, dentro do código.
3.	Nomear os arquivos .html da forma correta (veja a imagem no post do facebook). 
4.	Atendam aos requisitos acima, caso seu trabalho não se encaixe em quaisquer um deles, este será descartado e será solicitado nova entrega.
5.	Existe uma página modelo para cada uma que você vai precisar construir! Procure o modelo.
6.	Por favor, não esqueçam os print, maaas NÃO enviem prints pro Github, guarde-os com você que nós solicitaremos muito em breve.

------------------------------------------------------------------------------------

Sobre o GitHUB

1.	O repositório está renovado.
2.	A partir de hoje cada equipe tem um nome, e esse nome corresponde a uma “branch” no Github.
Uma equipe trabalhará somente numa branch. Não editem a branch alheia.
3.	Todos os trabalhos enviados passarão por testes e homologação.

------------------------------------------------------------------------------------

Obrigado!
